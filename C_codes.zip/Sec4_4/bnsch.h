void initialization(double **oc1, double **oc2, double **oc3);

void augmenc(double **c, int nxt, int nyt);

void cahn(double **c_old, double **mu, double **f, double **c_new);

void cahn2(double **cc_old, double **c_old, double **mu, double **f, double **of, double **c_new);

void source(double **c_old, double **f, double **src_c, double **src_mu);

void source2(double **cc_old, double **c_old, double **f, double **of, double **src_c, double **src_mu);

void laplace_ch(double **a, double **lap_a, int nxt, int nyt);

void vcycle(double **uf_new, double **wf_new, double **su, double **sw, int nxf, int nyf, int ilevel);

void vcycle2(double **uf_new, double **wf_new, double **su, double **sw, int nxf, int nyf, int ilevel);

void relax(double **c_new, double **mu_new, double **su, double **sw, int ilevel, int nxt, int nyt);

void relax2(double **c_new, double **mu_new, double **su, double **sw, int ilevel, int nxt, int nyt);

void defect(double **duc, double **dwc, double **uf_new, double **wf_new,
            double **suf, double **swf, int nxf, int nyf);

void defect2(double **duc, double **dwc, double **uf_new, double **wf_new,
            double **suf, double **swf, int nxf, int nyf);

void nonL(double **ru, double **rw, double **c_new, double **mu_new, int nxt, int nyt);

void nonL2(double **ru, double **rw, double **c_new, double **mu_new, int nxt, int nyt);

void restrict2(double **uf, double **uc, double **vf, double **vc, int nxt, int nyt);

void prolong_ch(double **uc, double **uf, double **vc, double **vf, int nxt, int nyt);

double error(double **c_old, double **c_new, int nxt, int nyt);


