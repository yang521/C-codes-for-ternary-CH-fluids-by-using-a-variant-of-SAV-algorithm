/************************************************

   Binary NSCH
   with variable density and variable viscosity

************************************************/

#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <time.h>
#include "util.h"
#include "bnsch.h"
#define NR_END 1
#define max(a,b) (a>b?a:b)
#define min(a,b) (a<b?a:b)

int nx, ny, n_level, p_relax, c_relax, count;
double pi, xleft, xright, yleft, yright, h, dt, gam, Cahn,  M, r, q, SS, Gam1, Gam2, Gam3, SJ, **beta, GamT, xi, V2,
        **worku, **workv, **workp, Ec,  **nworku, **nworkv, E1, E2, **lapmu1, **lapmu2, **lapmu3, GGam, **obeta, 
       **ct, **sc, **smu, **mu1, **mu2, **mu3, U, **f1, **f2, **f3,  **omu1, **omu2, **omu3, **intc1, **intc2, **intc3,
        **intmu1, **intmu2, **intmu3, **of1, **of2, **of3, **olapmu1, **olapmu2, **olapmu3, **gadmu1x, **gadmu1y,
        **gadmu2x, **gadmu2y, **gadmu3x, **gadmu3y, **intu, **intv, **fx, **fy, **tu, **tv, **adv_c, Re, **nworku, **nworkv,
        **adv_u, **adv_v, **lapu, **lapv, **rho, Fr, xio, rEc, bef_r;
char bufferc1[100],bufferc2[100], bufferc3[100], bufferu[100], bufferv[100],bufferp[100];
int main()
{
    extern int nx, ny, n_level, p_relax, c_relax, count;
    extern double pi, xleft, xright, yleft, yright, h, dt, gam, Cahn, M, Ec, SS, E1, E2, Gam1, Gam2, Gam3, SJ, GamT, xi, V2,
                  **worku, **workv, **workp,  r, q, **nworku, **nworkv, **lapmu1, **lapmu2, **lapmu3, **beta, GGam, **obeta,
                  **ct, **sc, **smu, **mu1, **mu2, **mu3,  **omu1, **omu2, **omu3, U, **f1, **f2, **f3, **intc1, **intc2, **intc3,
                  **intmu1, **intmu2, **intmu3, **of1, **of2, **of3, **olapmu1, **olapmu2, **olapmu3, **gadmu1x, **gadmu1y,
                  **gadmu2x, **gadmu2y, **gadmu3x, **gadmu3y, **intu, **intv, **fx, **fy, **tu, **tv, **adv_c, Re, **nworku, **nworkv,
                  **adv_u, **adv_v, **lapu, **lapv, **rho, Fr, xio, rEc, bef_r;
    extern char  bufferc1[100],bufferc2[100], bufferc3[100], bufferu[100], bufferv[100],bufferp[100];
    int it, max_it, ns, i, j;
    double **oc1, **nc1, **oc2, **nc2, **oc3, **ooc1, **ooc2, **ooc3, NoF1, **u, **nu, **ou, **v, **nv, **ov, **p, **np;
    
    FILE *fc1, *fc2, *fc3, *myr, *myq, *myor, *fu, *fv, *fp;
    
    
    /*****/
     
    nx = gnx;
    ny = gny;
    n_level = (int)(log(nx)/log(2)-0.9); 
    
    p_relax = 7;
    c_relax = 5;
    
    pi = 4.0*atan(1.0);
    
    xleft = 0.0, xright = 2.0;
    yleft = 0.0, yright = 1.0;
    
    count = 0;
    
    /***********************/
    
    h = xright/(double)nx;

    dt = 0.001;     
    gam = 0.018;   //4.0*h/(4.0*sqrt(2.0)*atanh(0.9));
    Cahn = pow(gam,2);
    
    max_it = 16000;
    ns = max_it/80;
    
    Gam1 = 12.0;  //4*0.4; //4.0; *//4*0.4; //4.0; //-4.0;//3.0; //0.4; //1.0; //-1.0;
    Gam2 = 12.0;  //4*1.6; //4.0; *//4*1.6; //4.0; //12.0;//3.0; //1.6; //1.0; //3.0;
    Gam3 = -4.0;  //4*1.2; //4.0; *//4*1.2; //4.0; //12.0;//-1.0; //1.2; //1.0; //3.0;

    GamT = 1.0/Gam1 + 1.0/Gam2 + 1.0/Gam3;

    SJ = 1.5; //7.0; //7.0;
    
    M = 0.01;

     Re = 1.0;
     
     Fr = 1.0;
    
    SS = 30.0;
    
    /***********************/
    
    printf("nx = %d, ny = %d\n", nx, ny);
    printf("n_level = %d\n", n_level);
    printf("dt      = %f\n", dt);
    printf("max_it  = %d\n", max_it);
    printf("ns      = %d\n", ns);
    
    

     adv_u = dmatrix(-1, nx+1, 0, ny+1);
     adv_v = dmatrix(-1, nx+1, 0, ny+1);

     lapu = dmatrix(-1, nx+1, 0, ny+1);
     lapv = dmatrix(-1, nx+1, 0, ny+1);
    
    gadmu1x = dmatrix(0, nx+1, 0, ny+1);
    gadmu1y = dmatrix(0, nx+1, 0, ny+1);
    
    gadmu2x = dmatrix(0, nx+1, 0, ny+1);
    gadmu2y = dmatrix(0, nx+1, 0, ny+1);
    
    gadmu3x = dmatrix(0, nx+1, 0, ny+1);
    gadmu3y = dmatrix(0, nx+1, 0, ny+1);
    
    beta = dmatrix(0, nx+1, 0, ny+1);
    obeta = dmatrix(0, nx+1, 0, ny+1);

    tu = dmatrix(-1, nx+1, 0, ny+1);
    intu = dmatrix(-1, nx+1, 0, ny+1);
    ou = dmatrix(-1, nx+1, 0, ny+1);
    u = dmatrix(-1, nx+1, 0, ny+1);
    nu = dmatrix(-1, nx+1, 0, ny+1);

    tv = dmatrix(0, nx+1, -1, ny+1);
    intv = dmatrix(0, nx+1, -1, ny+1);
    ov = dmatrix(0, nx+1, -1, ny+1);
    v = dmatrix(0, nx+1, -1, ny+1);
    nv = dmatrix(0, nx+1, -1, ny+1);

    adv_c = dmatrix(1, nx, 1, ny);
    fx = dmatrix(0, nx, 1, ny);
    fy = dmatrix(1, nx, 0, ny);

    nworku = dmatrix(0, nx, 1, ny);
    nworkv = dmatrix(1, nx, 0, ny);
    
    rho = dmatrix(0, nx+1, 0, ny+1);
    
    p = dmatrix(0, nx+1, 0, ny+1);
    np = dmatrix(0, nx+1, 0, ny+1);

    intc1 = dmatrix(0, nx+1, 0, ny+1);
    intc2 = dmatrix(0, nx+1, 0, ny+1);
    intc3 = dmatrix(0, nx+1, 0, ny+1);
    ooc1 = dmatrix(0, nx+1, 0, ny+1);
    ooc2 = dmatrix(0, nx+1, 0, ny+1);
    ooc3 = dmatrix(0, nx+1, 0, ny+1);
    oc1 = dmatrix(0, nx+1, 0, ny+1);
    oc2 = dmatrix(0, nx+1, 0, ny+1);
    oc3 = dmatrix(0, nx+1, 0, ny+1);
    nc1 = dmatrix(0, nx+1, 0, ny+1);
    nc2 = dmatrix(0, nx+1, 0, ny+1);

    worku = dmatrix(0, nx, 1, ny);
    workv = dmatrix(1, nx, 0, ny);
    nworku = dmatrix(0, nx, 1, ny);
    nworkv = dmatrix(1, nx, 0, ny);
    workp = dmatrix(1, nx, 1, ny);
    ct = dmatrix(1, nx, 1, ny);
    sc = dmatrix(1, nx, 1, ny);
    smu = dmatrix(1, nx, 1, ny);
    mu1 = dmatrix(0, nx+1, 0, ny+1);
    mu2 = dmatrix(0, nx+1, 0, ny+1);
    mu3 = dmatrix(0, nx+1, 0, ny+1);

    omu1 = dmatrix(0, nx+1, 0, ny+1);
    omu2 = dmatrix(0, nx+1, 0, ny+1);
    omu3 = dmatrix(0, nx+1, 0, ny+1);

    intmu1 = dmatrix(0, nx+1, 0, ny+1);
    intmu2 = dmatrix(0, nx+1, 0, ny+1);
    intmu3 = dmatrix(0, nx+1, 0, ny+1);

    lapmu1 = dmatrix(0, nx+1, 0, ny+1);
    lapmu2 = dmatrix(0, nx+1, 0, ny+1);
    lapmu3 = dmatrix(0, nx+1, 0, ny+1);
    
    olapmu1 = dmatrix(0, nx+1, 0, ny+1);
    olapmu2 = dmatrix(0, nx+1, 0, ny+1);
    olapmu3 = dmatrix(0, nx+1, 0, ny+1);

    f1 = dmatrix(0, nx+1, 0, ny+1);
    f2 = dmatrix(0, nx+1, 0, ny+1);
    f3 = dmatrix(0, nx+1, 0, ny+1);
    
    of1 = dmatrix(0, nx+1, 0, ny+1);
    of2 = dmatrix(0, nx+1, 0, ny+1);
    of3 = dmatrix(0, nx+1, 0, ny+1);
    
    
    zero_matrix(mu1, 1, nx, 1, ny); 
    zero_matrix(mu2, 1, nx, 1, ny); 
    zero_matrix(mu3, 1, nx, 1, ny); 
   
    sprintf(bufferu,"data1/datau.m");
   
    sprintf(bufferv,"data1/datav.m");

    sprintf(bufferp,"data1/datap.m");

    sprintf(bufferc1,"data1/datac1.m");
   
    sprintf(bufferc2,"data1/datac2.m");

    sprintf(bufferc3,"data1/datac3.m");

    fu = fopen(bufferu,"w"); 
   
    fv = fopen(bufferv,"w");
   
    fp = fopen(bufferp,"w");

    fc1 = fopen(bufferc1,"w");
   
    fc2 = fopen(bufferc2,"w");

    fc3 = fopen(bufferc3,"w");

    fclose(fu);
    
    fclose(fv);
    
    fclose(fp);
   
    fclose(fc1);
    
    fclose(fc2);

    fclose(fc3);
    
   
    
   
    initialization(u, v, p, oc1, oc2, oc3);
   
    
    ijloop{ rho[i][j] = 1.0; }
    
    augmenc(rho, nx, ny);
    
    
      augmenc(oc1, nx, ny);
      augmenc(oc2, nx, ny);
      augmenc(oc3, nx, ny);

      augmenuv(u, v);
      
      


  
     Ec  = 0.0;    
       ijloop{  Ec = Ec + (12.0/1)*( 0.5*Gam1*pow(oc1[i][j],2)*pow(1.0-oc1[i][j],2) + 0.5*Gam2*pow(oc2[i][j],2)*pow(1.0-oc2[i][j],2)
       + 0.5*Gam3*pow(oc3[i][j],2)*pow(1.0-oc3[i][j],2) + 3.0*SJ*pow(oc1[i][j],2)*pow(oc2[i][j],2)*pow(oc3[i][j],2) );
       }
       
       ijloop{
       
       Ec = Ec + (3.0*Gam1/8)*Cahn*( pow(oc1[i+1][j]-oc1[i-1][j],2) + pow(oc1[i][j+1]-oc1[i][j-1],2) )/(4*h*h)    
       + (3.0*Gam2/8)*Cahn*( pow(oc2[i+1][j]-oc2[i-1][j],2) + pow(oc2[i][j+1]-oc2[i][j-1],2) )/(4*h*h)     
       + (3.0*Gam3/8)*Cahn*( pow(oc3[i+1][j]-oc3[i-1][j],2) + pow(oc3[i][j+1]-oc3[i][j-1],2) )/(4*h*h);
       
       }

     i0jloop{   Ec = Ec + 0.5*u[i][j]*u[i][j]; }

     ij0loop{  Ec = Ec + 0.5*v[i][j]*v[i][j]; }
    
     q = Ec*h*h;
     
     r = q;

    mat_copy(ou, u, 0, nx, 1, ny);

   mat_copy(ov, v, 1, nx, 0, ny);
   
   mat_copy(nu, u, 0, nx, 1, ny);

   mat_copy(nv, v, 1, nx, 0, ny);
     
    mat_copy(nc1, oc1, 1, nx, 1, ny);

    mat_copy(nc2, oc2, 1, nx, 1, ny);

    mat_copy(ooc1, oc1, 1, nx, 1, ny);

    mat_copy(ooc2, oc2, 1, nx, 1, ny);

    mat_copy(ooc3, oc3, 1, nx, 1, ny);
    
    print_data(u, v, p, oc1,oc2,oc3);
    
    myr = fopen("data1/Mene.m","w");
    myq = fopen("data1/Oene.m","w");
   myor = fopen("data1/OOene.m","w");
    
    fprintf(myr,"%16.12f \n",r);
    fprintf(myq,"%16.12f \n",q);
    fprintf(myor,"%16.12f \n",q);


    for (it=1; it<=1; it++) {

      ijloop{
          
         f1[i][j] = 0.5*Gam1*(2.0*pow(oc1[i][j],3)-3.0*pow(oc1[i][j],2)+oc1[i][j]) + 6.0*SJ*oc1[i][j]*pow(oc2[i][j],2)*pow(oc3[i][j],2);

         f2[i][j] = 0.5*Gam2*(2.0*pow(oc2[i][j],3)-3.0*pow(oc2[i][j],2)+oc2[i][j]) + 6.0*SJ*oc2[i][j]*pow(oc1[i][j],2)*pow(oc3[i][j],2);

         f3[i][j] = 0.5*Gam3*(2.0*pow(oc3[i][j],3)-3.0*pow(oc3[i][j],2)+oc3[i][j]) + 6.0*SJ*oc3[i][j]*pow(oc1[i][j],2)*pow(oc2[i][j],2);

       }


    ijloop{  
  
      beta[i][j] = -(1.0/GamT)*(f1[i][j]/Gam1 + f2[i][j]/Gam2 + f3[i][j]/Gam3);

      }
      
      
      augmenc(oc1, nx, ny);
      augmenc(oc2, nx, ny);
      augmenc(oc3, nx, ny);

    
       Ec  = 0.0;    
       ijloop{  Ec = Ec + (12.0/1)*( 0.5*Gam1*pow(oc1[i][j],2)*pow(1.0-oc1[i][j],2) + 0.5*Gam2*pow(oc2[i][j],2)*pow(1.0-oc2[i][j],2)
       + 0.5*Gam3*pow(oc3[i][j],2)*pow(1.0-oc3[i][j],2) + 3.0*SJ*pow(oc1[i][j],2)*pow(oc2[i][j],2)*pow(oc3[i][j],2) );
       }
       
       ijloop{
       
       Ec = Ec + (3.0*Gam1/8)*Cahn*( pow(oc1[i+1][j]-oc1[i-1][j],2) + pow(oc1[i][j+1]-oc1[i][j-1],2) )/(4*h*h)    
       + (3.0*Gam2/8)*Cahn*( pow(oc2[i+1][j]-oc2[i-1][j],2) + pow(oc2[i][j+1]-oc2[i][j-1],2) )/(4*h*h)     
       + (3.0*Gam3/8)*Cahn*( pow(oc3[i+1][j]-oc3[i-1][j],2) + pow(oc3[i][j+1]-oc3[i][j-1],2) )/(4*h*h);
       
       }


     i0jloop{ Ec = Ec + 0.5*u[i][j]*u[i][j]; }
 
     ij0loop{ Ec = Ec + 0.5*v[i][j]*v[i][j]; }

    
        Ec = Ec*h*h;


      augmenc(mu1, nx, ny);
      augmenc(mu2, nx, ny);
      augmenc(mu3, nx, ny);
       

    ijloop{  

        lapmu1[i][j] = (mu1[i+1][j]+mu1[i-1][j]+mu1[i][j+1]+mu1[i][j-1]-4.0*mu1[i][j])/(h*h);
        lapmu2[i][j] = (mu2[i+1][j]+mu2[i-1][j]+mu2[i][j+1]+mu2[i][j-1]-4.0*mu2[i][j])/(h*h);
        lapmu3[i][j] = (mu3[i+1][j]+mu3[i-1][j]+mu3[i][j+1]+mu3[i][j-1]-4.0*mu3[i][j])/(h*h);

     }


    augmenuv(u, v);

   i0jloop{ lapu[i][j] = ( u[i+1][j]+u[i-1][j]+u[i][j+1]+u[i][j-1]-4.0*u[i][j] )/(h*h); }

   ij0loop{ lapv[i][j] = ( v[i+1][j]+v[i-1][j]+v[i][j+1]+v[i][j-1]-4.0*v[i][j] )/(h*h); }


     NoF1 = 0.0;

     ijloop{ 

     NoF1 = NoF1 + lapmu1[i][j]*mu1[i][j]/Gam1 + lapmu2[i][j]*mu2[i][j]/Gam2 + lapmu3[i][j]*mu3[i][j]/Gam3;

     }

    NoF1 = NoF1*M;

   i0jloop{ NoF1 = NoF1 + lapu[i][j]*u[i][j]*(1.0/Re); }

   ij0loop{ NoF1 = NoF1 + lapv[i][j]*v[i][j]*(1.0/Re); }


    NoF1 = NoF1*h*h;


     r = r/(1.0 - NoF1*dt/Ec);
   
     
     
      printf("Value of r %16.14f\n", r);
      printf("Value of Ec %16.14f\n", Ec);



    //fluid part

    augmenc(oc1, nx, ny);
    augmenc(oc2, nx, ny);
    augmenc(oc3, nx, ny);
    augmenc(mu1, nx, ny);
    augmenc(mu2, nx, ny);
    augmenc(mu3, nx, ny);
    
   

     i0jloop{ fx[i][j] = 0.5*(oc1[i+1][j]+oc1[i][j])*(mu1[i+1][j]-mu1[i][j])/(h)
                             + 0.5*(oc2[i+1][j]+oc2[i][j])*(mu2[i+1][j]-mu2[i][j])/(h)
                             + 0.5*(oc3[i+1][j]+oc3[i][j])*(mu3[i+1][j]-mu3[i][j])/(h);
        }

    ij0loop{ fy[i][j] = 0.5*(oc1[i][j+1]+oc1[i][j])*(mu1[i][j+1]-mu1[i][j])/(h)
                            + 0.5*(oc2[i][j+1]+oc2[i][j])*(mu2[i][j+1]-mu2[i][j])/(h)
                            + 0.5*(oc3[i][j+1]+oc3[i][j])*(mu3[i][j+1]-mu3[i][j])/(h);

       }


     i0jloop{ fx[i][j] = fx[i][j]/0.1;
        }

    ij0loop{ fy[i][j] = fy[i][j]/0.1;

       }



     full_step(u, v, fx, fy, nu, nv, p, np);

 
        mat_copy(omu1, mu1, 1, nx, 1, ny);
        mat_copy(omu2, mu2, 1, nx, 1, ny);
        mat_copy(omu3, mu3, 1, nx, 1, ny);

        advection_step(u, v, oc1, adv_c);
 
         GGam = Gam1;
         cahn(oc1, mu1, adv_c, f1, nc1);

        advection_step(u, v, oc2, adv_c);
 
         GGam = Gam2;
         cahn(oc2, mu2, adv_c, f2, nc2);

         
    ijloop{

        oc3[i][j] = 1.0 - nc1[i][j] - nc2[i][j];

        mu3[i][j] = -Gam3*(mu1[i][j]/Gam1 + mu2[i][j]/Gam2);

       }
       
       
      augmenc(nc1, nx, ny);
      augmenc(nc2, nx, ny);
      augmenc(oc3, nx, ny);
       

 //calculate the original energy
     Ec  = 0.0;    
       ijloop{  Ec = Ec + (12.0/1)*( 0.5*Gam1*pow(nc1[i][j],2)*pow(1.0-nc1[i][j],2) + 0.5*Gam2*pow(nc2[i][j],2)*pow(1.0-nc2[i][j],2)
       + 0.5*Gam3*pow(oc3[i][j],2)*pow(1.0-oc3[i][j],2) + 3.0*SJ*pow(nc1[i][j],2)*pow(nc2[i][j],2)*pow(oc3[i][j],2) );
       }
       
       ijloop{
       
       Ec = Ec + (3.0*Gam1/8)*Cahn*( pow(nc1[i+1][j]-nc1[i-1][j],2) + pow(nc1[i][j+1]-nc1[i][j-1],2) )/(4*h*h)    
       + (3.0*Gam2/8)*Cahn*( pow(nc2[i+1][j]-nc2[i-1][j],2) + pow(nc2[i][j+1]-nc2[i][j-1],2) )/(4*h*h)     
       + (3.0*Gam3/8)*Cahn*( pow(oc3[i+1][j]-oc3[i-1][j],2) + pow(oc3[i][j+1]-oc3[i][j-1],2) )/(4*h*h);
       
       }

    i0jloop{ Ec = Ec + 0.5*nu[i][j]*nu[i][j]; }

    ij0loop{ Ec = Ec + 0.5*nv[i][j]*nv[i][j]; }


     q = Ec*h*h;
        
       
        mat_copy(oc1, nc1, 1, nx, 1, ny);
        mat_copy(oc2, nc2, 1, nx, 1, ny);

        mat_copy(p, np, 1, nx, 1, ny);

        mat_copy(u, nu, 0, nx, 1, ny);
        mat_copy(v, nv, 1, nx, 0, ny);
        
        printf("it = %d\n", it);
        
       /* if (it % ns == 0) {
            count++;
            print_data(nu, nv, np, nc1, nc2, oc3);
            fprintf(myr,"%16.12f \n",r);
            fprintf(myq,"%16.12f \n",q);
            printf("print out counts %d\n", count);
        }*/


    }


    
    for (it=2; it<=max_it; it++) {


     ijloop{

        intc1[i][j] = 2.0*oc1[i][j] - ooc1[i][j];
        intc2[i][j] = 2.0*oc2[i][j] - ooc2[i][j];
        intc3[i][j] = 2.0*oc3[i][j] - ooc3[i][j];

       }

      ijloop{
          
         f1[i][j] = 0.5*Gam1*(2.0*pow(intc1[i][j],3)-3.0*pow(intc1[i][j],2)+intc1[i][j]) + 6.0*SJ*intc1[i][j]*pow(intc2[i][j],2)*pow(intc3[i][j],2);

         f2[i][j] = 0.5*Gam2*(2.0*pow(intc2[i][j],3)-3.0*pow(intc2[i][j],2)+intc2[i][j]) + 6.0*SJ*intc2[i][j]*pow(intc1[i][j],2)*pow(intc3[i][j],2);

         f3[i][j] = 0.5*Gam3*(2.0*pow(intc3[i][j],3)-3.0*pow(intc3[i][j],2)+intc3[i][j]) + 6.0*SJ*intc3[i][j]*pow(intc1[i][j],2)*pow(intc2[i][j],2);

       }


    ijloop{  
  
      beta[i][j] = -(1.0/GamT)*(f1[i][j]/Gam1 + f2[i][j]/Gam2 + f3[i][j]/Gam3);

      }


    i0jloop{ intu[i][j] = 2.0*u[i][j] - ou[i][j]; }

    ij0loop{ intv[i][j] = 2.0*v[i][j] - ov[i][j]; }
      
      
      
      augmenc(intc1, nx, ny);
      augmenc(intc2, nx, ny);
      augmenc(intc3, nx, ny);

    
       Ec  = 0.0;    
       ijloop{  Ec = Ec + (12.0/1)*( 0.5*Gam1*pow(intc1[i][j],2)*pow(1.0-intc1[i][j],2) + 0.5*Gam2*pow(intc2[i][j],2)*pow(1.0-intc2[i][j],2)
       + 0.5*Gam3*pow(intc3[i][j],2)*pow(1.0-intc3[i][j],2) + 3.0*SJ*pow(intc1[i][j],2)*pow(intc2[i][j],2)*pow(intc3[i][j],2) );
       }
       
       ijloop{
       
       Ec = Ec + (3.0*Gam1/8)*Cahn*( pow(intc1[i+1][j]-intc1[i-1][j],2) + pow(intc1[i][j+1]-intc1[i][j-1],2) )/(4*h*h)    
       + (3.0*Gam2/8)*Cahn*( pow(intc2[i+1][j]-intc2[i-1][j],2) + pow(intc2[i][j+1]-intc2[i][j-1],2) )/(4*h*h)     
       + (3.0*Gam3/8)*Cahn*( pow(intc3[i+1][j]-intc3[i-1][j],2) + pow(intc3[i][j+1]-intc3[i][j-1],2) )/(4*h*h);
       
       }

      i0jloop{ Ec = Ec + 0.5*intu[i][j]*intu[i][j]; }

      ij0loop{ Ec = Ec + 0.5*intv[i][j]*intv[i][j]; }
  
    
        Ec = Ec*h*h;


         rEc = Ec;


     ijloop{

       intmu1[i][j] = 2.0*mu1[i][j] - omu1[i][j];
       intmu2[i][j] = 2.0*mu2[i][j] - omu2[i][j];
       intmu3[i][j] = 2.0*mu3[i][j] - omu3[i][j];

       }
       
      augmenc(intmu1, nx, ny);
      augmenc(intmu2, nx, ny);
      augmenc(intmu3, nx, ny);
       


    augmenuv(intu, intv);

   i0jloop{ lapu[i][j] = ( intu[i+1][j]+intu[i-1][j]+intu[i][j+1]+intu[i][j-1]-4.0*intu[i][j] )/(h*h); }

   ij0loop{ lapv[i][j] = ( intv[i+1][j]+intv[i-1][j]+intv[i][j+1]+intv[i][j-1]-4.0*intv[i][j] )/(h*h); }

     
      ijloop{  

        lapmu1[i][j] = (intmu1[i+1][j]+intmu1[i-1][j]+intmu1[i][j+1]+intmu1[i][j-1]-4.0*intmu1[i][j])/(h*h);
        lapmu2[i][j] = (intmu2[i+1][j]+intmu2[i-1][j]+intmu2[i][j+1]+intmu2[i][j-1]-4.0*intmu2[i][j])/(h*h);
        lapmu3[i][j] = (intmu3[i+1][j]+intmu3[i-1][j]+intmu3[i][j+1]+intmu3[i][j-1]-4.0*intmu3[i][j])/(h*h);
        
      }
     


     NoF1 = 0.0;

     ijloop{ 

     NoF1 = NoF1 + lapmu1[i][j]*intmu1[i][j]/Gam1 + lapmu2[i][j]*intmu2[i][j]/Gam2 + lapmu3[i][j]*intmu3[i][j]/Gam3;

     }

    NoF1 = NoF1*M;

   i0jloop{ NoF1 = NoF1 + lapu[i][j]*intu[i][j]*(1.0/Re); }

   ij0loop{ NoF1 = NoF1 + lapv[i][j]*intv[i][j]*(1.0/Re); }

 
    NoF1 = NoF1*h*h;


     r = r/(1.0 - NoF1*dt/Ec);

      bef_r = r;

     xi = r/Ec;
    
     V2 = xi*(2.0-xi);

     
      printf("Value of r %16.14f\n", r);
      printf("Value of Ec %16.14f\n", Ec);
      printf("Value of V2 %16.14f\n", V2);


     //fluid part

    augmenc(intc1, nx, ny);
    augmenc(intc2, nx, ny);
    augmenc(intc3, nx, ny);
    augmenc(intmu1, nx, ny);
    augmenc(intmu2, nx, ny);
    augmenc(intmu3, nx, ny);

     i0jloop{ fx[i][j] = 0.5*(intc1[i+1][j]+intc1[i][j])*(intmu1[i+1][j]-intmu1[i][j])/(h)
                             + 0.5*(intc2[i+1][j]+intc2[i][j])*(intmu2[i+1][j]-intmu2[i][j])/(h)
                             + 0.5*(intc3[i+1][j]+intc3[i][j])*(intmu3[i+1][j]-intmu3[i][j])/(h);
        }

    ij0loop{ fy[i][j] =0.5*(intc1[i][j+1]+intc1[i][j])*(intmu1[i][j+1]-intmu1[i][j])/(h)
                            + 0.5*(intc2[i][j+1]+intc2[i][j])*(intmu2[i][j+1]-intmu2[i][j])/(h)
                            + 0.5*(intc3[i][j+1]+intc3[i][j])*(intmu3[i][j+1]-intmu3[i][j])/(h);

       }
       
  
    i0jloop{ fx[i][j] = fx[i][j]/0.1;
        }

    ij0loop{ fy[i][j] = fy[i][j]/0.1;

       }

      full_step2(u, v, ou, ov, fx, fy, nu, nv, p, np);


        mat_copy(omu1, mu1, 1, nx, 1, ny);
        mat_copy(omu2, mu2, 1, nx, 1, ny);
        mat_copy(omu3, mu3, 1, nx, 1, ny);

         advection_step(intu, intv, intc1, adv_c);

         GGam = Gam1;
         cahn2(ooc1, oc1, mu1, adv_c, f1, of1, nc1);

         advection_step(intu, intv, intc2, adv_c);
 
         GGam = Gam2;
         cahn2(ooc2, oc2, mu2, adv_c, f2, of2, nc2);
         
         
          mat_copy(ooc3, oc3, 1, nx, 1, ny);

         
    ijloop{

        oc3[i][j] = 1.0 - nc1[i][j] - nc2[i][j];

        mu3[i][j] = -Gam3*(mu1[i][j]/Gam1 + mu2[i][j]/Gam2);

       }
       
       
      augmenc(nc1, nx, ny);
      augmenc(nc2, nx, ny);
      augmenc(oc3, nx, ny);
       

 //calculate the original energy
     Ec  = 0.0;    
       ijloop{  Ec = Ec + (12.0/1)*( 0.5*Gam1*pow(nc1[i][j],2)*pow(1.0-nc1[i][j],2) + 0.5*Gam2*pow(nc2[i][j],2)*pow(1.0-nc2[i][j],2)
       + 0.5*Gam3*pow(oc3[i][j],2)*pow(1.0-oc3[i][j],2) + 3.0*SJ*pow(nc1[i][j],2)*pow(nc2[i][j],2)*pow(oc3[i][j],2) );
       }
       
       ijloop{
       
       Ec = Ec + (3.0*Gam1/8)*Cahn*( pow(nc1[i+1][j]-nc1[i-1][j],2) + pow(nc1[i][j+1]-nc1[i][j-1],2) )/(4*h*h)    
       + (3.0*Gam2/8)*Cahn*( pow(nc2[i+1][j]-nc2[i-1][j],2) + pow(nc2[i][j+1]-nc2[i][j-1],2) )/(4*h*h)     
       + (3.0*Gam3/8)*Cahn*( pow(oc3[i+1][j]-oc3[i-1][j],2) + pow(oc3[i][j+1]-oc3[i][j-1],2) )/(4*h*h);
       
       }


        i0jloop{ Ec = Ec + 0.5*nu[i][j]*nu[i][j]; }

       ij0loop{ Ec = Ec + 0.5*nv[i][j]*nv[i][j]; }

     q = Ec*h*h;


        //relax:
     
    if ( (r < q) && (r - q + r*NoF1*dt/rEc < 0) ){
     xio = 1.0 - dt*r*NoF1/(rEc*(q-r));
     r = xio*r + (1.0-xio)*q;

     }
    else{
     r = q;
 
     }
        
       
        mat_copy(ooc1, oc1, 1, nx, 1, ny);
        mat_copy(ooc2, oc2, 1, nx, 1, ny);
        mat_copy(oc1, nc1, 1, nx, 1, ny);
        mat_copy(oc2, nc2, 1, nx, 1, ny);

        mat_copy(p, np, 1, nx, 1, ny);

        mat_copy(ou, u, 0, nx, 1, ny);
        mat_copy(u, nu, 0, nx, 1, ny);

        mat_copy(ov, v, 1, nx, 0, ny);
        mat_copy(v, nv, 1, nx, 0, ny);
        
        printf("it = %d\n", it);
        
        if (it % ns == 0) {
            count++;
            print_data(nu, nv, np, nc1, nc2, oc3);
            fprintf(myr,"%16.12f \n",r);
            fprintf(myq,"%16.12f \n",q);
             fprintf(myor,"%16.12f \n",bef_r);
            printf("print out counts %d\n", count);
        }
    }
    
    return 0;
}

void initialization(double **u, double **v, double **p, double **oc1, double **oc2, double **oc3)
{
    extern double xright, yright, h, gam;
    
    int i, j;
    double x, y;
    
    ijloop {
        x = ((double)i-0.5)*h;
        y = ((double)j-0.5)*h;
        
       oc1[i][j] = 0.5 + 0.5*tanh((0.25 - sqrt(pow(x-1.26,2) + pow(y-0.4,2)) )/gam);

       oc2[i][j] = 0.5 + 0.5*tanh((0.25 - sqrt(pow(x-0.74,2) + pow(y-0.6,2)) )/gam);
     
      oc3[i][j] = 1.0 - oc1[i][j] - oc2[i][j];

       p[i][j] = 0.0;
  
    }


   i0jloop{

    y = ((double)j-0.5)*h;

    u[i][j] = 0.5*(y-0.5);

   }
  


   ij0loop{ v[i][j] = 0.0; }
   
  
    
 
}



void full_step(double **u, double **v, double **fx, double **fy, double **nu, double **nv,  double **p, double **np)
{
    extern int nx, ny;
    extern double dt, **tu, **tv, **worku, **workv, **nworku, **nworkv, **adv_u, **adv_v;
    
    int i, j;
     

    advection_uv(u, v, adv_u, adv_v);
    
     grad_p(p, worku, workv, nx, ny);     
    
    temp_uv(tu, tv, u, v, worku, workv, fx, fy, adv_u, adv_v);
    
    augmenuv(tu, tv);
           
    Poisson(tu, tv, p, np);
    
    grad_p(np, nworku, nworkv, nx, ny);
    
    i0jloop {
        nu[i][j] = tu[i][j] - dt*(nworku[i][j] - worku[i][j]);
    }
    
    ij0loop {
        nv[i][j] = tv[i][j] - dt*(nworkv[i][j] - workv[i][j]);
    }
    
}



void full_step2(double **u, double **v, double **ou, double **ov, double **fx, double **fy, double **nu, double **nv,  double **p, double **np)
{
    extern int nx, ny;
    extern double dt, **intu, **intv, **tu, **tv, **worku, **workv, **nworku, **nworkv, **adv_u, **adv_v;
    
    int i, j;
     

    advection_uv(intu, intv, adv_u, adv_v);
    
     grad_p(p, worku, workv, nx, ny);     
    
    temp_uv2(tu, tv, u, v, ou, ov, worku, workv, fx, fy, adv_u, adv_v);
    
    augmentuv(tu, tv);
           
    Poisson2(tu, tv, p, np);
    
    grad_p(np, nworku, nworkv, nx, ny);
    
    i0jloop {
        nu[i][j] = ( 3.0*tu[i][j] - 2.0*dt*(nworku[i][j] - worku[i][j]) )/3.0;
    }
    
    ij0loop {
        nv[i][j] = ( 3.0*tv[i][j] - 2.0*dt*(nworkv[i][j] - workv[i][j]) )/3.0;
    }
    
}


void temp_uv(double **tu, double **tv, double **u, double **v, double **worku, double **workv, double **fx, double **fy, double **adv_u, double **adv_v)
{
    int i,j, it_mg = 1, max_it = 500;
    extern double r, Ec, h, dt;
    double residu = 1.0, residv = 1.0, tol = 1.0e-5, **soru, **sorv,  **su, **sv;

    soru = dmatrix(0, nx, 1, ny);
    sorv = dmatrix(1, nx, 0, ny);
    
    su = dmatrix(0, nx, 1, ny);
    sv = dmatrix(1, nx, 0, ny);


    i0jloop{ 
       su[i][j] = u[i][j]/dt -adv_u[i][j] - worku[i][j] - fx[i][j];
     }

    ij0loop{
      sv[i][j] = v[i][j]/dt - adv_v[i][j] - workv[i][j] - fy[i][j];
   }
   
  

     while (it_mg <= max_it && residu >= tol && residv >= tol) {
        
        relax_uv(tu, tv, su, sv, nx, ny);
        
        mat_sub(soru, soru, tu, 0, nx, 1, ny);
        mat_sub(sorv, sorv, tv, 1, nx, 0, ny);
        residu = mat_max(soru, 0, nx, 1, ny);
        residv = mat_max(sorv, 1, nx, 0, ny);
        mat_copy(soru, tu, 0, nx, 1, ny);
        mat_copy(sorv, tv, 1, nx, 0, ny);
        
        it_mg++;
    }
   

     printf("Velocity1 iteration = %d ", it_mg-1);

  
     free_dmatrix(soru, 0, nx, 1, ny);
     free_dmatrix(sorv, 1, nx, 0, ny);

     free_dmatrix(su, 0, nx, 1, ny);
     free_dmatrix(sv, 1, nx, 0, ny);
    
}


void temp_uv2(double **tu, double **tv, double **u, double **v, double **ou, double **ov, double **worku, double **workv, double **fx, double **fy, double **adv_u, double **adv_v)
{
    int i,j, it_mg = 1, max_it = 500;
    extern double V2, h, dt;
    double residu = 1.0, residv = 1.0, tol = 1.0e-5, **soru, **sorv,  **su, **sv;

    soru = dmatrix(0, nx, 1, ny);
    sorv = dmatrix(1, nx, 0, ny);
    
    su = dmatrix(0, nx, 1, ny);
    sv = dmatrix(1, nx, 0, ny);


    i0jloop{ 
       su[i][j] = (4.0*u[i][j]-ou[i][j])/(2.0*dt) -adv_u[i][j] - worku[i][j] - fx[i][j];
     }

    ij0loop{
      sv[i][j] = (4.0*v[i][j]-ov[i][j])/(2.0*dt) - adv_v[i][j] - workv[i][j] - fy[i][j];
   }
   
  

     while (it_mg <= max_it && residu >= tol && residv >= tol) {
        
        relax_uv2(tu, tv, su, sv, nx, ny);
        
        mat_sub(soru, soru, tu, 0, nx, 1, ny);
        mat_sub(sorv, sorv, tv, 1, nx, 0, ny);
        residu = mat_max(soru, 0, nx, 1, ny);
        residv = mat_max(sorv, 1, nx, 0, ny);
        mat_copy(soru, tu, 0, nx, 1, ny);
        mat_copy(sorv, tv, 1, nx, 0, ny);
        
        it_mg++;
    }
   

     printf("Velocity1 iteration = %d ", it_mg-1);

  
     free_dmatrix(soru, 0, nx, 1, ny);
     free_dmatrix(sorv, 1, nx, 0, ny);

     free_dmatrix(su, 0, nx, 1, ny);
     free_dmatrix(sv, 1, nx, 0, ny);
    
}


void relax_uv(double **tu, double **tv, double **su, double **sv, int nx, int ny)
{
    extern double xright, dt, Re, h;
    
    int i, j, iter;
    double h2, sorc, coef;
    
    h2 = pow(h,2);
    
    for (iter=1; iter<=5; iter++) {
    
    
   augmenuv(tu, tv);
  

  //Jacobi
     i0jloop {     
            
            sorc = su[i][j] + (tu[i+1][j]+tu[i-1][j]+tu[i][j+1]+tu[i][j-1])/(Re*h2);
            coef = 1.0/dt + 4.0/(Re*h2);
        
            tu[i][j] = sorc/coef;
        }
        
        
      ij0loop {     
            
            sorc = sv[i][j] + (tv[i+1][j]+tv[i-1][j]+tv[i][j+1]+tv[i][j-1])/(Re*h2);
            coef = 1.0/dt + 4.0/(Re*h2);
        
            tv[i][j] = sorc/coef;
        }
   }
    
}


void relax_uv2(double **tu, double **tv, double **su, double **sv, int nx, int ny)
{
    extern double xright, dt, Re, h;
    
    int i, j, iter;
    double h2, sorc, coef;
    
    h2 = pow(h,2);
    
    for (iter=1; iter<=5; iter++) {
    
    
   augmenuv(tu, tv);
  

  //Jacobi
     i0jloop {     
            
            sorc = su[i][j] + (tu[i+1][j]+tu[i-1][j]+tu[i][j+1]+tu[i][j-1])/(Re*h2);
            coef = 3.0/(2.0*dt) + 4.0/(Re*h2);
        
            tu[i][j] = sorc/coef;
        }
        
        
      ij0loop {     
            
            sorc = sv[i][j] + (tv[i+1][j]+tv[i-1][j]+tv[i][j+1]+tv[i][j-1])/(Re*h2);
            coef = 3.0/(2.0*dt) + 4.0/(Re*h2);
        
            tv[i][j] = sorc/coef;
        }
   }
    
}


void Poisson(double **tu, double **tv, double **p, double **np)
{
    extern int nx, ny;
    extern double **workp;
    
    source_uv(tu, tv, p, workp, nx, ny);
    
    MG_Poisson(np, workp);
    
}

void Poisson2(double **tu, double **tv, double **p, double **np)
{
    extern int nx, ny;
    extern double **workp;
    
    source_uv2(tu, tv, p, workp, nx, ny);
    
    MG_Poisson(np, workp);
    
}

void source_uv(double **tu, double **tv, double **p, double **divuv, int nxt, int nyt)
{
    extern double dt, h;
    
    int i, j;
    
    div_uv(tu, tv, divuv, nxt, nyt);

    augmenc(p, nxt, nyt);
    
    ijloopt {
        divuv[i][j] = divuv[i][j]/dt + (p[i+1][j]+p[i-1][j]+p[i][j+1]+p[i][j-1]-4.0*p[i][j])/(h*h);
    }
    
}

void source_uv2(double **tu, double **tv, double **p, double **divuv, int nxt, int nyt)
{
    extern double dt, h;
    
    int i, j;
    
    div_uv(tu, tv, divuv, nxt, nyt);

    augmenc(p, nxt, nyt);
    
    ijloopt {
        divuv[i][j] = 3.0*divuv[i][j]/(2.0*dt) + (p[i+1][j]+p[i-1][j]+p[i][j+1]+p[i][j-1]-4.0*p[i][j])/(h*h);
    }
    
}


void div_uv(double **tu, double **tv, double **divuv, int nxt, int nyt)
{
    extern double xright;
    
    int i, j;
    double ht;
    
    ht = xright/(double)nxt;
    
    ijloopt {
        divuv[i][j] = (tu[i][j] - tu[i-1][j] + tv[i][j] - tv[i][j-1])/ht;
    }
    
}

void MG_Poisson(double **p, double **f)
{
    extern int nx, ny;
    extern double **rho;
    
    int it_mg = 1, max_it = 100;
    double resid = 1.0, resid2 = 10.0, tol = 1.0e-5, **sor;
    
    sor = dmatrix(1, nx, 1, ny);
    
    mat_copy(sor, p, 1, nx, 1, ny);
    
    while (it_mg <= max_it && resid >= tol) {
        
        vcycle_uv(p, f, rho, nx, ny, 1);
        
        pressure_update(p);
        
        mat_sub(sor, sor, p, 1, nx, 1, ny);
        resid = mat_max(sor, 1, nx, 1, ny);
        mat_copy(sor, p, 1, nx, 1, ny);
        
        if (resid > resid2)
            it_mg = max_it;
        else
            resid2 = resid;
        
        it_mg++;
    }
    printf("Mac pressure iteration = %d   residual = %16.14f\n", it_mg-1, resid);
    
    free_dmatrix(sor, 1, nx, 1, ny);
    
    return;
}

void vcycle_uv(double **uf, double **ff, double **wf, int nxf, int nyf, int ilevel)
{
    extern int n_level;
    
    relax_p(uf, ff, wf, ilevel, nxf, nyf);
    
    if (ilevel < n_level) {
        
        int nxc, nyc;
        double **rf, **fc, **uc, **wc;
        
        nxc = nxf/2, nyc = nyf/2;
        
        rf = dmatrix(1, nxf, 1, nyf);
        fc = dmatrix(1, nxc, 1, nyc);
        uc = dmatrix(1, nxc, 1, nyc);
        wc = dmatrix(0, nxc+1, 0, nyc+1);
        
        residual_den(rf, uf, ff, wf, nxf, nyf);
        
        restrict1(rf, fc, nxc, nyc);
        
        restrict1(wf, wc, nxc, nyc);
        
        augmenc(wc, nxc, nyc);
        
        zero_matrix(uc, 1, nxc, 1, nyc);
        
        vcycle_uv(uc, fc, wc, nxc, nyc, ilevel+1);
        
        prolong(uc, rf, nxc, nyc);
        
        mat_add(uf, uf, rf, 1, nxf, 1, nyf);
        
        relax_p(uf, ff, wf, ilevel, nxf, nyf);
        
        free_dmatrix(rf, 1, nxf, 1, nyf);
        free_dmatrix(fc, 1, nxc, 1, nyc);
        free_dmatrix(uc, 1, nxc, 1, nyc);
        free_dmatrix(wc, 0, nxc+1, 0, nyc+1);
    }
    
}

void relax_p(double **p, double **f, double **w, int ilevel, int nxt, int nyt)
{
    extern int ny, p_relax;
    extern double xright, Fr;
    
    int i, j, iter;
    double ht, ht2, a[4], sorc, coef;
    
    ht = xright/(double)nxt;
    ht2 = pow(ht,2);
    
    for (iter=1; iter<=p_relax; iter++) {
        
        ijloopt {
            a[0] = 2.0/(w[i+1][j]+w[i][j]); 
            a[1] = 2.0/(w[i][j]+w[i-1][j]);
            a[2] = 2.0/(w[i][j+1]+w[i][j]);
            a[3] = 2.0/(w[i][j]+w[i][j-1]);
            
            sorc = f[i][j];
            coef = -(a[0] + a[1])/ht2;
            
            if (i==1)
                sorc -= (a[0]*p[i+1][j] + a[1]*p[nxt][j])/ht2;
            else if (i==nxt)
                sorc -= (a[0]*p[1][j] + a[1]*p[i-1][j])/ht2;
            else
                sorc -= (a[0]*p[i+1][j] + a[1]*p[i-1][j])/ht2;
            
            if (j==1) { 
                if (nyt==ny)
                    sorc -= a[2]*p[i][j+1]/ht2 + 0.0/(ht*Fr);
                else
                    sorc -= a[2]*p[i][j+1]/ht2;
                
                coef -= a[2]/ht2;
            }
            else if (j==nyt) {
                if (nyt==ny)
                    sorc -= -0.0/(ht*Fr) + a[3]*p[i][j-1]/ht2;
                else
                    sorc -= a[3]*p[i][j-1]/ht2;
                
                coef -= a[3]/ht2;
            }
            else {
                sorc -= (a[2]*p[i][j+1] + a[3]*p[i][j-1])/ht2;
                coef -= (a[2] + a[3])/ht2;
            }
            
            p[i][j] = sorc/coef;
        }
    }
    
}

void residual_den(double **r, double **u, double **f, double **den, int nxt, int nyt)
{
    int i, j;
    double **dpdx, **dpdy;
    
    dpdx = dmatrix(0, nxt, 1, nyt);
    dpdy = dmatrix(1, nxt, 0, nyt);
    
    grad_p(u, dpdx, dpdy, nxt, nyt);
    
    i0jloopt {
        dpdx[i][j] = dpdx[i][j]/(0.5*(den[i+1][j]+den[i][j]));
    }
    
    ij0loopt {
        dpdy[i][j] = dpdy[i][j]/(0.5*(den[i][j+1]+den[i][j]));
    }
    
    div_uv(dpdx, dpdy, r, nxt, nyt);
    mat_sub(r, f, r, 1, nxt, 1, nyt);
    
    free_dmatrix(dpdx, 0, nxt, 1, nyt);
    free_dmatrix(dpdy, 1, nxt, 0, nyt);
}

void grad_p(double **p, double **dpdx, double **dpdy, int nxt, int nyt)
{
    extern double xright, Fr, **rho;
    
    int i, j;
    double ht;
    
    ht = xright/(double)nxt;
    
    i0jloopt {
        if (i==0)
            dpdx[0][j] = (p[1][j] - p[nxt][j])/ht;
        else if (i==nxt)
            dpdx[nxt][j] = (p[1][j] - p[nxt][j])/ht;
        else
            dpdx[i][j] = (p[i+1][j] - p[i][j])/ht;
    }
    
    ij0loopt {
        if (j==0) {
            if (nyt==ny)
                dpdy[i][0] = -0.0*(rho[i][1]+rho[i][0])/Fr;
            else
                dpdy[i][0] = 0.0;
        }
        else if (j==nyt) {
            if (nyt==ny)
                dpdy[i][nyt] = -0.0*(rho[i][nyt+1]+rho[i][nyt])/Fr;
            else
                dpdy[i][nyt] = 0.0;
        }
        
        else
            dpdy[i][j] = (p[i][j+1] - p[i][j])/ht;
    }
    
}

void restrict1(double **u_fine, double **u_coarse, int nxt, int nyt)
{
    int i, j;
    
    ijloopt {
        u_coarse[i][j] = 0.25*(u_fine[2*i-1][2*j-1] + u_fine[2*i-1][2*j]
                             + u_fine[2*i][2*j-1] + u_fine[2*i][2*j]);
    }
    
}

void prolong(double **u_coarse, double **u_fine, int nxt, int nyt)
{
    int i, j;
    
    ijloopt {
        u_fine[2*i-1][2*j-1] = u_fine[2*i-1][2*j] =
        u_fine[2*i][2*j-1] = u_fine[2*i][2*j] = u_coarse[i][j];
    }
    
}


void pressure_update(double **a)
{
    extern int nx, ny;
    
    int i, j;
    double ave = 0.0;
    
    ijloop {
        ave = ave + a[i][j];
    }
    ave /= (nx+0.0)*(ny+0.0);
    
    ijloop {
        a[i][j] -= ave;
    }
    
    return;
}


void augmenc(double **c, int nxt, int nyt)
{
    int i, j;
    
    for (j=1; j<=nyt; j++) { 
        c[0][j] = c[nxt][j];
        c[nxt+1][j] = c[1][j];
    }
    
    for (i=0; i<=nxt+1; i++) { 
        c[i][0] = c[i][1];
        c[i][nyt+1] = c[i][nyt];
    }
    
}

void augmenuv(double **u, double **v)
{
    extern int nx, ny;
    
    int i, j;
    double aa;
    
    for (j=1; j<=ny; j++) {
        aa = 0.5*(u[0][j]+u[nx][j]);
        u[0][j] = u[nx][j] = aa;
        u[-1][j] = u[nx-1][j];
        u[nx+1][j] = u[1][j];
    }
    
    for (i=-1; i<=nx+1; i++) {
        u[i][0] = -0.25 -u[i][1];
        u[i][ny+1] = 0.25 -u[i][ny];
    }
    
    for (j=0; j<=ny; j++) {
        v[0][j] = v[nx][j];
        v[nx+1][j] = v[1][j];
    }
    
    for (i=0; i<=nx+1; i++) {
        v[i][0] = v[i][ny] = 0.0;
        v[i][-1] = -v[i][1];
        v[i][ny+1] = -v[i][ny-1];
    }
    
}

void augmentuv(double **u, double **v)
{
    extern int nx, ny;
    
    int i, j;
    double aa;
    
    for (j=1; j<=ny; j++) {
        aa = 0.5*(u[0][j]+u[nx][j]);
        u[0][j] = u[nx][j] = aa;
        u[-1][j] = u[nx-1][j];
        u[nx+1][j] = u[1][j];
    }
    
    for (i=-1; i<=nx+1; i++) {
        u[i][0] = 0.0 -u[i][1];
        u[i][ny+1] = 0.0 -u[i][ny];
    }
    
    for (j=0; j<=ny; j++) {
        v[0][j] = v[nx][j];
        v[nx+1][j] = v[1][j];
    }
    
    for (i=0; i<=nx+1; i++) {
        v[i][0] = v[i][ny] = 0.0;
        v[i][-1] = -v[i][1];
        v[i][ny+1] = -v[i][ny-1];
    }
    
}


void advection_step(double **u, double **v, double **c, double **adv_c)
{
    extern int nx, ny;
    extern double h;
    
    int i, j;
    
    augmenuv(u, v);
    augmenc(c, nx, ny);
    
    ijloop { // conservative
        adv_c[i][j] = (u[i][j]*(c[i+1][j]+c[i][j])-u[i-1][j]*(c[i][j]+c[i-1][j]))/(2.0*h)
                    + (v[i][j]*(c[i][j+1]+c[i][j])-v[i][j-1]*(c[i][j]+c[i][j-1]))/(2.0*h);
    }
    
}


void advection_uv(double **u, double **v, double **adv_u, double **adv_v)
{
    extern int nx, ny;
    extern double h;
    double a, b, d, **ux, **uy, **vx, **vy;
    
    int i, j, k;

    ux = dmatrix(-1, nx, 1, ny);
    uy = dmatrix(0, nx, 0, ny);
    vx = dmatrix(0, nx, 0, ny);
    vy = dmatrix(1, nx, -1, ny);
    
    augmenuv(u, v);

  // Up-wind scheme 
   
 
    i0jloop {
        if (u[i][j] > 0.0)
            adv_u[i][j] = u[i][j]*(u[i][j]-u[i-1][j])/h;
        else
            adv_u[i][j] = u[i][j]*(u[i+1][j]-u[i][j])/h;
        
        if (v[i][j-1]+v[i+1][j-1]+v[i][j]+v[i+1][j] > 0.0)
            adv_u[i][j] += 0.25*(v[i][j-1]+v[i+1][j-1]+v[i][j]+v[i+1][j])*(u[i][j]-u[i][j-1])/h;
        else
            adv_u[i][j] += 0.25*(v[i][j-1]+v[i+1][j-1]+v[i][j]+v[i+1][j])*(u[i][j+1]-u[i][j])/h;
    }
    
    ij0loop {
        if (u[i-1][j]+u[i][j]+u[i-1][j+1]+u[i][j+1] > 0.0)
            adv_v[i][j] = 0.25*(u[i-1][j]+u[i][j]+u[i-1][j+1]+u[i][j+1])*(v[i][j]-v[i-1][j])/h;
        else
            adv_v[i][j] = 0.25*(u[i-1][j]+u[i][j]+u[i-1][j+1]+u[i][j+1])*(v[i+1][j]-v[i][j])/h;
        
        if (v[i][j] > 0.0)
            adv_v[i][j] += v[i][j]*(v[i][j]-v[i][j-1])/h;
        else
            adv_v[i][j] += v[i][j]*(v[i][j+1]-v[i][j])/h;
    }
   



    //2nd_order ENO scheme

  /*  for (i=0; i<=nx-1; i++) 
       for (j=1; j<=ny; j++){

          // u-part 

        if( (u[i][j] + u[i+1][j]) >= 0.0 )  k = i;
        else                              k = i+1;

           a = (u[k][j] - u[k-1][j])/h;
           b = (u[k+1][j]-u[k][j])/h; 

        if( fabs(a) <= fabs(b)  )   d = a;
        else                        d = b;
 
      ux[i][j] = u[k][j] + 0.5*h*d*( 1.0-2.0*(k-i) );    
      
    }
    
  
    
   for (i=0; i<=nx; i++) 
       for (j=1; j<=ny-1; j++){
       
      if( (v[i][j] + v[i+1][j]) >= 0.0 ) k = j;
      else                             k = j+1;
  
          a = (u[i][k] - u[i][k-1])/h;
          b = (u[i][k+1]-u[i][k])/h;
    
       if( fabs(a) <= fabs(b) ) d = a;
       else                     d = b;

      uy[i][j] = u[i][k] + 0.5*h*d*( 1.0-2.0*(k-j) );
      
}


    // v-part 
    

   for (i=1; i<=nx-1; i++) 
       for (j=0; j<=ny; j++){
  
          if( (u[i][j] + u[i][j+1]) >= 0.0 )    k = i;
             else                             k = i+1;

        a = (v[k][j] - v[k-1][j])/h;
        b = (v[k+1][j]-v[k][j])/h; 

        if( fabs(a) <= fabs(b)  )   d = a;
        else                        d = b;

        vx[i][j] = v[k][j] + 0.5*h*d*( 1.0-2.0*(k-i) );    
        
    }
    
    
    for (i=1; i<=nx; i++) 
       for (j=0; j<=ny-1; j++){
       
        if( (v[i][j] + v[i][j+1]) >= 0.0 ) k = j;
        else                             k = j+1;
  
          a = (v[i][k] - v[i][k-1])/h;
          b = (v[i][k+1]-v[i][k])/h;
    
       if( fabs(a) <= fabs(b) ) d = a;
       else                     d = b;

      vy[i][j] = v[i][k] + 0.5*h*d*( 1.0-2.0*(k-j) );


     }
     
     
    for (j=1; j<=ny; j++){ ux[-1][j] = ux[nx-1][j];  ux[nx][j] = ux[0][j]; }
    for (i=0; i<=nx; i++){ uy[i][0] = 0.0;  uy[i][ny] = 0.0; }
    for (j=0; j<=ny; j++){  vx[0][j] = vx[1][j]; vx[nx][j] = vx[nx-1][j]; }
    for (i=1; i<=nx; i++){ vy[i][-1] = 0.0;   vy[i][ny] = 0.0;  }


 i0jloop { adv_u[i][j] = u[i][j]*(ux[i][j] - ux[i-1][j])/h + 0.25*(v[i][j-1]+v[i+1][j-1]+v[i][j]+v[i+1][j])*(uy[i][j] - uy[i][j-1])/h;  }

 ij0loop{  adv_v[i][j] = 0.25*(u[i-1][j]+u[i][j]+u[i-1][j+1]+u[i][j+1])*(vx[i][j] - vx[i-1][j])/h  + v[i][j]*(vy[i][j] - vy[i][j-1])/h;  }

*/
    free_dmatrix(ux, -1, nx, 1, ny);
    free_dmatrix(uy, 0, nx, 0, ny);
    free_dmatrix(vx, 0, nx, 0, ny);
    free_dmatrix(vy, 1, nx, -1, ny);
    
}

void cahn(double **c_old, double **mu, double **adv_c, double **f, double **c_new)
{
    extern int nx, ny;
    extern double **ct, **sc, **smu;
    
    int it_mg = 1, max_it_CH = 200;
    double resid = 1.0, tol = 1.0e-6;
    
    mat_copy(ct, c_old, 1, nx, 1, ny);
    
    source(c_old, f, adv_c, sc, smu);
    
    while (it_mg <= max_it_CH && resid > tol) {
        
        vcycle(c_new, mu, sc, smu, nx ,ny, 1);
        resid = error(ct, c_new, nx, ny);
        mat_copy(ct, c_new, 1, nx, 1, ny);
        
        it_mg++;
    }
    printf("cahn %16.14f   %d\n", resid, it_mg-1);
}


void cahn2(double **cc_old, double **c_old, double **mu, double **adv_c, double **f, double **of, double **c_new)
{
    extern int nx, ny;
    extern double **ct, **sc, **smu;
    
    int it_mg = 1, max_it_CH = 200;
    double resid = 1.0, tol = 1.0e-6;
    
    mat_copy(ct, c_old, 1, nx, 1, ny);
    
    source2(cc_old, c_old, f, of, adv_c, sc, smu);
    
    while (it_mg <= max_it_CH && resid > tol) {
        
        vcycle2(c_new, mu, sc, smu, nx ,ny, 1);
        resid = error(ct, c_new, nx, ny);
        mat_copy(ct, c_new, 1, nx, 1, ny);
        
        it_mg++;
    }
    printf("cahn %16.14f   %d\n", resid, it_mg-1);
}


void source(double **c_old, double **f, double **adv_c, double **src_c, double **src_mu)
{
    extern int nx, ny;
    extern double dt, SS, gam, r, M, Ec, **beta, GGam;
    
    int i, j;
    
    augmenc(c_old, nx, ny);
   
    ijloop {
        src_c[i][j] = c_old[i][j]/(M*dt) - adv_c[i][j]/M;
        src_mu[i][j] = (12.0/1)*(f[i][j] + beta[i][j])*(Ec/r) - (SS/1)*GGam*c_old[i][j];
        //- (SS/1)*GGam*(c_old[i+1][j]+c_old[i-1][j]+c_old[i][j+1]+c_old[i][j-1]-4.0*c_old[i][j])/(h*h);
    }
    
}



void source2(double **cc_old, double **c_old, double **f, double **of, double **adv_c, double **src_c, double **src_mu)
{
    extern int nx, ny;
    extern double dt, SS, gam, r, M, Ec, **beta, GGam, V2, **obeta;
    
    int i, j;
    
    augmenc(c_old, nx, ny);
    augmenc(cc_old, nx, ny);
   
    ijloop {
        src_c[i][j] = (4.0*c_old[i][j]-cc_old[i][j])/(2.0*M*dt) - adv_c[i][j]/M;
        src_mu[i][j] = (12.0/1)*(f[i][j]+ beta[i][j])*V2 - (SS/1)*GGam*(2.0*c_old[i][j]-cc_old[i][j]);
        //-(SS/1)*GGam*( 2.0*(c_old[i+1][j]+c_old[i-1][j]+c_old[i][j+1]+c_old[i][j-1]-4.0*c_old[i][j])/(h*h)
         //  - (cc_old[i+1][j]+cc_old[i-1][j]+cc_old[i][j+1]+cc_old[i][j-1]-4.0*cc_old[i][j])/(h*h)  );
    }
    
}


void laplace_ch(double **a, double **lap_a, int nxt, int nyt)
{
    extern double xright;
    
    int i, j;
    double ht2, dadx_L, dadx_R, dady_B, dady_T;
    
    ht2 = pow(xright/(double)nxt,2);
    
    ijloopt {
        
        if (i > 1)
            dadx_L = a[i][j] - a[i-1][j];
        else
            dadx_L = a[i][j] - a[nxt][j];
        
        if (i < nxt)
            dadx_R = a[i+1][j] - a[i][j];
        else
            dadx_R = a[1][j] - a[i][j];
        
        if (j > 1)
            dady_B = a[i][j] - a[i][j-1];
        else
            dady_B = 0.0;
        
        if (j < nyt)
            dady_T = a[i][j+1] - a[i][j];
        else
            dady_T = 0.0;
        
        lap_a[i][j] = (dadx_R - dadx_L + dady_T - dady_B)/ht2;
    }
    
}

void vcycle(double **uf_new, double **wf_new, double **su, double **sw, int nxf, int nyf, int ilevel)
{
    extern int n_level;
    
    relax(uf_new, wf_new, su, sw, ilevel, nxf, nyf);
    
    if (ilevel < n_level) {
        
        int nxc, nyc;
        double **uc_new, **wc_new, **duc, **dwc,
               **uc_def, **wc_def, **uf_def, **wf_def;
        
        nxc = nxf/2, nyc = nyf/2;
        
        uc_new = dmatrix(1, nxc, 1, nyc);
        wc_new = dmatrix(1, nxc, 1, nyc);
        duc = dmatrix(1, nxc, 1, nyc);
        dwc = dmatrix(1, nxc, 1, nyc);
        uc_def = dmatrix(1, nxc, 1, nyc);
        wc_def = dmatrix(1, nxc, 1, nyc);
        uf_def = dmatrix(1, nxf, 1, nyf);
        wf_def = dmatrix(1, nxf, 1, nyf);
        
       // restrict2(uf_new, uc_new, wf_new, wc_new, nxc, nyc);
        
        defect(duc, dwc, uf_new, wf_new, su, sw, nxf, nyf);

          zero_matrix(uc_def, 1, nxc, 1, nyc);
          zero_matrix(wc_def, 1, nxc, 1, nyc);
        
        vcycle(uc_def, wc_def, duc, dwc, nxc, nyc, ilevel+1);
        
     //   mat_sub2(uc_def, uc_def, uc_new, wc_def, wc_def, wc_new, 1, nxc, 1, nyc);
        
        prolong_ch(uc_def, uf_def, wc_def, wf_def, nxc, nyc);
        
        mat_add2(uf_new, uf_new, uf_def, wf_new, wf_new, wf_def, 1, nxf, 1, nyf);
        
        relax(uf_new, wf_new, su, sw, ilevel, nxf, nyf);
        
        free_dmatrix(uc_new, 1, nxc, 1, nyc);
        free_dmatrix(wc_new, 1, nxc, 1, nyc);
        free_dmatrix(duc, 1, nxc, 1, nyc);
        free_dmatrix(dwc, 1, nxc, 1, nyc);
        free_dmatrix(uc_def, 1, nxc, 1, nyc);
        free_dmatrix(wc_def, 1, nxc, 1, nyc);
        free_dmatrix(uf_def, 1, nxf, 1, nyf);
        free_dmatrix(wf_def, 1, nxf, 1, nyf);
    }

}


void vcycle2(double **uf_new, double **wf_new, double **su, double **sw, int nxf, int nyf, int ilevel)
{
    extern int n_level;
    
    relax2(uf_new, wf_new, su, sw, ilevel, nxf, nyf);
    
    if (ilevel < n_level) {
        
        int nxc, nyc;
        double **uc_new, **wc_new, **duc, **dwc,
               **uc_def, **wc_def, **uf_def, **wf_def;
        
        nxc = nxf/2, nyc = nyf/2;
        
        uc_new = dmatrix(1, nxc, 1, nyc);
        wc_new = dmatrix(1, nxc, 1, nyc);
        duc = dmatrix(1, nxc, 1, nyc);
        dwc = dmatrix(1, nxc, 1, nyc);
        uc_def = dmatrix(1, nxc, 1, nyc);
        wc_def = dmatrix(1, nxc, 1, nyc);
        uf_def = dmatrix(1, nxf, 1, nyf);
        wf_def = dmatrix(1, nxf, 1, nyf);
        
       // restrict2(uf_new, uc_new, wf_new, wc_new, nxc, nyc);
        
        defect2(duc, dwc, uf_new, wf_new, su, sw, nxf, nyf);

          zero_matrix(uc_def, 1, nxc, 1, nyc);
          zero_matrix(wc_def, 1, nxc, 1, nyc);
        
        vcycle2(uc_def, wc_def, duc, dwc, nxc, nyc, ilevel+1);
        
     //   mat_sub2(uc_def, uc_def, uc_new, wc_def, wc_def, wc_new, 1, nxc, 1, nyc);
        
        prolong_ch(uc_def, uf_def, wc_def, wf_def, nxc, nyc);
        
        mat_add2(uf_new, uf_new, uf_def, wf_new, wf_new, wf_def, 1, nxf, 1, nyf);
        
        relax2(uf_new, wf_new, su, sw, ilevel, nxf, nyf);
        
        free_dmatrix(uc_new, 1, nxc, 1, nyc);
        free_dmatrix(wc_new, 1, nxc, 1, nyc);
        free_dmatrix(duc, 1, nxc, 1, nyc);
        free_dmatrix(dwc, 1, nxc, 1, nyc);
        free_dmatrix(uc_def, 1, nxc, 1, nyc);
        free_dmatrix(wc_def, 1, nxc, 1, nyc);
        free_dmatrix(uf_def, 1, nxf, 1, nyf);
        free_dmatrix(wf_def, 1, nxf, 1, nyf);
    }

}


void relax(double **c_new, double **mu_new, double **su, double **sw, int ilevel, int nxt, int nyt)
{
    extern int c_relax;
    extern double xright, dt, Cahn, GGam, gam, M, SS;
    
    int i, j, iter;
    double ht2, a[4], f[2], det;
    
    ht2 = pow(xright/(double)nxt,2);
    
    for (iter=1; iter<=c_relax; iter++) {
        
        ijloopt {
            a[0] = 1.0/(M*dt);
            
            a[1] = 2.0/(ht2*GGam);
            if (j > 1)   a[1] += 1.0/(ht2*GGam);
            if (j < nyt) a[1] += 1.0/(ht2*GGam);
            
            a[2] = - 2.0*(3.0/4)*Cahn*GGam/ht2 - (SS/1)*GGam; // + 2.0*(SS/1)*GGam/ht2;
            if (j > 1)   a[2] += -(3.0/4)*Cahn*GGam/ht2; // + (SS/1)*GGam/ht2;
            if (j < nyt) a[2] += -(3.0/4)*Cahn*GGam/ht2; // + (SS/1)*GGam/ht2;
            
            a[3] = 1.0;
            
            f[0] = su[i][j];
            if (i > 1)   f[0] += mu_new[i-1][j]/(ht2*GGam);
            else         f[0] += mu_new[nxt][j]/(ht2*GGam);
            
            if (i < nxt) f[0] += mu_new[i+1][j]/(ht2*GGam);
            else         f[0] += mu_new[1][j]/(ht2*GGam);
            
            if (j > 1)   f[0] += mu_new[i][j-1]/(ht2*GGam);
            if (j < nyt) f[0] += mu_new[i][j+1]/(ht2*GGam);
            
            f[1] = sw[i][j];
            if (i > 1)   f[1] += -(3.0/4)*Cahn*GGam*c_new[i-1][j]/ht2; // + (SS/1)*GGam*c_new[i-1][j]/ht2;
            else         f[1] += -(3.0/4)*Cahn*GGam*c_new[nxt][j]/ht2; // + (SS/1)*GGam*c_new[nxt][j]/ht2;
            
            if (i < nxt) f[1] += -(3.0/4)*Cahn*GGam*c_new[i+1][j]/ht2; // + (SS/1)*GGam*c_new[i+1][j]/ht2;
            else         f[1] += -(3.0/4)*Cahn*GGam*c_new[1][j]/ht2; // + (SS/1)*GGam*c_new[1][j]/ht2;
            
            if (j > 1)   f[1] += -(3.0/4)*Cahn*GGam*c_new[i][j-1]/ht2; // + (SS/1)*GGam*c_new[i][j-1]/ht2;
            if (j < nyt) f[1] += -(3.0/4)*Cahn*GGam*c_new[i][j+1]/ht2; // + (SS/1)*GGam*c_new[i][j+1]/ht2;
            
            det = a[0]*a[3] - a[1]*a[2];
            
            c_new[i][j] = (a[3]*f[0] - a[1]*f[1])/det;
            mu_new[i][j] = (-a[2]*f[0] + a[0]*f[1])/det;
        }
    }
    
}


void relax2(double **c_new, double **mu_new, double **su, double **sw, int ilevel, int nxt, int nyt)
{
    extern int c_relax;
    extern double xright, dt, Cahn, GGam, gam, M, SS;
    
    int i, j, iter;
    double ht2, a[4], f[2], det;
    
    ht2 = pow(xright/(double)nxt,2);
    
    for (iter=1; iter<=c_relax; iter++) {
        
        ijloopt {
            a[0] = 3.0/(2.0*M*dt);
            
            a[1] = 2.0/(ht2*GGam);
            if (j > 1)   a[1] += 1.0/(ht2*GGam);
            if (j < nyt) a[1] += 1.0/(ht2*GGam);
            
             a[2] = - 2.0*(3.0/4)*Cahn*GGam/ht2 - (SS/1)*GGam; //+ 2.0*(SS/1)*GGam/ht2;
            if (j > 1)   a[2] += -(3.0/4)*Cahn*GGam/ht2; // + (SS/1)*GGam/ht2;
            if (j < nyt) a[2] += -(3.0/4)*Cahn*GGam/ht2; // + (SS/1)*GGam/ht2;
            
            a[3] = 1.0;
            
            f[0] = su[i][j];
            if (i > 1)   f[0] += mu_new[i-1][j]/(ht2*GGam);
            else         f[0] += mu_new[nxt][j]/(ht2*GGam);
            
            if (i < nxt) f[0] += mu_new[i+1][j]/(ht2*GGam);
            else         f[0] += mu_new[1][j]/(ht2*GGam);
            
            if (j > 1)   f[0] += mu_new[i][j-1]/(ht2*GGam);
            if (j < nyt) f[0] += mu_new[i][j+1]/(ht2*GGam);
            
            f[1] = sw[i][j];
            if (i > 1)   f[1] += -(3.0/4)*Cahn*GGam*c_new[i-1][j]/ht2; // + (SS/1)*GGam*c_new[i-1][j]/ht2;
            else         f[1] += -(3.0/4)*Cahn*GGam*c_new[nxt][j]/ht2; // + (SS/1)*GGam*c_new[nxt][j]/ht2;
            
            if (i < nxt) f[1] += -(3.0/4)*Cahn*GGam*c_new[i+1][j]/ht2; // + (SS/1)*GGam*c_new[i+1][j]/ht2;
            else         f[1] += -(3.0/4)*Cahn*GGam*c_new[1][j]/ht2; // + (SS/1)*GGam*c_new[1][j]/ht2;
            
            if (j > 1)   f[1] += -(3.0/4)*Cahn*GGam*c_new[i][j-1]/ht2; // + (SS/1)*GGam*c_new[i][j-1]/ht2;
            if (j < nyt) f[1] += -(3.0/4)*Cahn*GGam*c_new[i][j+1]/ht2; // + (SS/1)*GGam*c_new[i][j+1]/ht2;
            
            det = a[0]*a[3] - a[1]*a[2];
            
            c_new[i][j] = (a[3]*f[0] - a[1]*f[1])/det;
            mu_new[i][j] = (-a[2]*f[0] + a[0]*f[1])/det;
        }
    }
    
}

void defect(double **duc, double **dwc, double **uf_new, double **wf_new,
            double **suf, double **swf, int nxf, int nyf)
{
    double **ruf, **rwf, **rruf, **rrwf;
    
    ruf = dmatrix(1, nxf, 1, nyf);
    rwf = dmatrix(1, nxf, 1, nyf);
    rruf = dmatrix(1, nxf/2, 1, nyf/2);
    rrwf = dmatrix(1, nxf/2, 1, nyf/2);
    
    nonL(ruf, rwf, uf_new, wf_new, nxf, nyf);
    
    mat_sub2(ruf, suf, ruf, rwf, swf, rwf, 1, nxf, 1, nyf);
    
    restrict2(ruf, duc, rwf, dwc, nxf/2, nyf/2);
    
    free_dmatrix(ruf, 1, nxf, 1, nyf);
    free_dmatrix(rwf, 1, nxf, 1, nyf);
    free_dmatrix(rruf, 1, nxf/2, 1, nyf/2);
    free_dmatrix(rrwf, 1, nxf/2, 1, nyf/2);
}


void defect2(double **duc, double **dwc, double **uf_new, double **wf_new,
            double **suf, double **swf, int nxf, int nyf)
{
    double **ruf, **rwf, **rruf, **rrwf;
    
    ruf = dmatrix(1, nxf, 1, nyf);
    rwf = dmatrix(1, nxf, 1, nyf);
    rruf = dmatrix(1, nxf/2, 1, nyf/2);
    rrwf = dmatrix(1, nxf/2, 1, nyf/2);
    
    nonL2(ruf, rwf, uf_new, wf_new, nxf, nyf);
    
    mat_sub2(ruf, suf, ruf, rwf, swf, rwf, 1, nxf, 1, nyf);
    
    restrict2(ruf, duc, rwf, dwc, nxf/2, nyf/2);
    
    free_dmatrix(ruf, 1, nxf, 1, nyf);
    free_dmatrix(rwf, 1, nxf, 1, nyf);
    free_dmatrix(rruf, 1, nxf/2, 1, nyf/2);
    free_dmatrix(rrwf, 1, nxf/2, 1, nyf/2);
}

void nonL(double **ru, double **rw, double **c_new, double **mu_new, int nxt, int nyt)
{
    extern double dt, gam, Cahn, GGam, M, SS;
    
    int i, j;
    double **lap_c, **lap_mu;
    
    lap_c = dmatrix(1, nxt, 1, nyt);
    lap_mu = dmatrix(1, nxt, 1, nyt);
    
    laplace_ch(c_new, lap_c, nxt, nyt);
    laplace_ch(mu_new, lap_mu, nxt, nyt);
    
    ijloopt {
        ru[i][j] = c_new[i][j]/(M*dt) - lap_mu[i][j]/GGam;
        rw[i][j] = mu_new[i][j] + (3.0/4)*Cahn*GGam*lap_c[i][j] - (SS/1)*GGam*c_new[i][j]; // - (SS/1)*GGam*lap_c[i][j];
    }
    
    free_dmatrix(lap_c, 1, nxt, 1, nyt);
    free_dmatrix(lap_mu, 1, nxt, 1, nyt);
}


void nonL2(double **ru, double **rw, double **c_new, double **mu_new, int nxt, int nyt)
{
    extern double dt, gam, Cahn, GGam, M, SS;
    
    int i, j;
    double **lap_c, **lap_mu;
    
    lap_c = dmatrix(1, nxt, 1, nyt);
    lap_mu = dmatrix(1, nxt, 1, nyt);
    
    laplace_ch(c_new, lap_c, nxt, nyt);
    laplace_ch(mu_new, lap_mu, nxt, nyt);
    
    ijloopt {
        ru[i][j] = 3.0*c_new[i][j]/(2.0*M*dt) - lap_mu[i][j]/GGam;
        rw[i][j] = mu_new[i][j] + (3.0/4)*Cahn*GGam*lap_c[i][j] - (SS/1)*GGam*c_new[i][j]; // - (SS/1)*GGam*lap_c[i][j];
    }
    
    free_dmatrix(lap_c, 1, nxt, 1, nyt);
    free_dmatrix(lap_mu, 1, nxt, 1, nyt);
}

void restrict2(double **uf, double **uc, double **vf, double **vc, int nxt, int nyt)
{
    int i, j;
    
    ijloopt {
        uc[i][j] = 0.25*(uf[2*i-1][2*j-1] + uf[2*i-1][2*j] + uf[2*i][2*j-1] + uf[2*i][2*j]);
        vc[i][j] = 0.25*(vf[2*i-1][2*j-1] + vf[2*i-1][2*j] + vf[2*i][2*j-1] + vf[2*i][2*j]);
    }
    
}

void prolong_ch(double **uc, double **uf, double **vc, double **vf, int nxt, int nyt)
{
    int i, j;
    
    ijloopt {
        uf[2*i-1][2*j-1] = uf[2*i-1][2*j] = uf[2*i][2*j-1] = uf[2*i][2*j] = uc[i][j];
        vf[2*i-1][2*j-1] = vf[2*i-1][2*j] = vf[2*i][2*j-1] = vf[2*i][2*j] = vc[i][j];
    }
    
}

double error(double **c_old, double **c_new, int nxt, int nyt)
{
    double **r, res;
    
    r = dmatrix(1, nxt, 1, nyt);
    
    mat_sub(r, c_new, c_old, 1, nxt, 1, nyt);
    res = mat_max(r, 1, nxt, 1, nyt);
    
    free_dmatrix(r, 1, nxt, 1, nyt);
    
    return res;
}


/*************** util ****************/
double **dmatrix(long nrl, long nrh, long ncl, long nch)
{
    double **m;
    long i, nrow=nrh-nrl+1+NR_END, ncol=nch-ncl+1+NR_END;
    
    m=(double **) malloc((nrow)*sizeof(double*));
    m+=NR_END;
    m-=nrl;
    
    m[nrl]=(double *) malloc((nrow*ncol)*sizeof(double));
    m[nrl]+=NR_END;
    m[nrl]-=ncl;
    
    for (i=nrl+1; i<=nrh; i++) m[i]=m[i-1]+ncol;
    
    return m;
}

void free_dmatrix(double **m, long nrl, long nrh, long ncl, long nch)
{
    free(m[nrl]+ncl-NR_END);
    free(m+nrl-NR_END);
    
    return;
}

void zero_matrix(double **a, int xl, int xr, int yl, int yr)
{
    int i, j;
    
    for (i=xl; i<=xr; i++) {
        for (j=yl; j<=yr; j++) {
            a[i][j] = 0.0;
        }
    }
    
    return;
}

void mat_copy(double **a, double **b, int xl, int xr, int yl, int yr)
{
    int i, j;
    
    for (i=xl; i<=xr; i++) {
        for (j=yl; j<=yr; j++) {
            a[i][j] = b[i][j];
        }
    }
    
    return;
}

void mat_copy2(double **a, double **b, double **a2, double **b2,
               int xl, int xr, int yl, int yr)
{
    int i, j;
    
    for (i=xl; i<=xr; i++) {
        for (j=yl; j<=yr; j++) {
            a[i][j] = b[i][j];
            a2[i][j] = b2[i][j];
        }
    }
    
    return;
}

void mat_add(double **a, double **b, double **c,
             int xl, int xr, int yl, int yr)
{
    int i, j;
    
    for (i=xl; i<=xr; i++) {
        for (j=yl; j<=yr; j++) {
            a[i][j] = b[i][j]+c[i][j];
        }
    }
    
    return;
}

void mat_add2(double **a, double **b, double **c,
              double **a2, double **b2, double **c2,
              int xl, int xr, int yl, int yr)
{
    int i, j;
    
    for (i=xl; i<=xr; i++) {
        for (j=yl; j<=yr; j++) {
            a[i][j] = b[i][j]+c[i][j];
            a2[i][j] = b2[i][j]+c2[i][j];
        }
    }
    
    return;
}

void mat_sub(double **a, double **b, double **c,
             int nrl, int nrh, int ncl, int nch)
{
    int i, j;
    
    for (i=nrl; i<=nrh; i++) {
        for (j=ncl; j<=nch; j++) {
            a[i][j] = b[i][j]-c[i][j];
        }
    }
    
    return;
}

void mat_sub2(double **a, double **b, double **c,
              double **a2, double **b2, double **c2,
              int nrl, int nrh, int ncl, int nch)
{
    int i, j;
    
    for (i=nrl; i<=nrh; i++) {
        for (j=ncl; j<=nch; j++) {
            a[i][j] = b[i][j]-c[i][j];
            a2[i][j] = b2[i][j]-c2[i][j];
        }
    }
    
    return;
}

double mat_max(double **a, int nrl, int nrh, int ncl, int nch)
{
    int i, j;
    double x = 0.0;
    
    for (i=nrl; i<=nrh; i++) {
        for (j=ncl; j<=nch; j++) {
            if (fabs(a[i][j]) > x)
                x = fabs(a[i][j]);
        }
    }
    
    return x;
}


void print_mat(FILE *fptr, double **a, int nrl, int nrh, int ncl, int nch)
{
    int i, j;
    
    for (i=nrl; i<=nrh; i++) {
        for (j=ncl; j<=nch; j++)
            fprintf(fptr, "   %16.14f", a[i][j]);
        
        fprintf(fptr, "\n");
    }
    
    return;
}


void print_data(double **u, double **v, double **p, double **c1, double **c2, double **c3)
{
    extern char  bufferu[100],  bufferv[100],  bufferp[100], bufferc1[100],bufferc2[100],bufferc3[100];
    int i, j;
   FILE *fu, *fv, *fp, *fc1, *fc2, *fc3;

    fu = fopen(bufferu,"a"); 
    fv = fopen(bufferv,"a");
    fp = fopen(bufferp,"a");
    
    fc1 = fopen(bufferc1,"a");
    fc2 = fopen(bufferc2,"a");
    fc3 = fopen(bufferc3,"a");
   

   iloop {
        jloop {

           fprintf(fu, "  %16.14f", 0.5*(u[i][j]+u[i-1][j]));
           fprintf(fv, "  %16.14f", 0.5*(v[i][j]+v[i][j-1]));
           fprintf(fp, "  %16.14f", p[i][j]);

           fprintf(fc1, "  %16.14f", c1[i][j]);
           fprintf(fc2, "  %16.14f", c2[i][j]);
           fprintf(fc3, "  %16.14f", c3[i][j]);
	   }

                   fprintf(fu, "\n");
	   fprintf(fv, "\n");
	   fprintf(fp, "\n");

	   fprintf(fc1, "\n");
	   fprintf(fc2, "\n");
                   fprintf(fc3, "\n");
    }
  
    fclose(fu);
    fclose(fv);
    fclose(fp);

    fclose(fc1);
    fclose(fc2);
    fclose(fc3);
    

  return;
}



