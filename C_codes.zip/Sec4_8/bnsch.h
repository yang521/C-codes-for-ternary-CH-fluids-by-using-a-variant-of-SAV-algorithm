void initialization(double **u, double **v, double **p, double **oc1, double **oc2, double **oc3);

void full_step(double **u, double **v, double **fx, double **fy, double **nu, double **nv,  double **p, double **np);

void full_step2(double **u, double **v, double **ou, double **ov, double **fx, double **fy, double **nu, double **nv,  double **p, double **np);

void temp_uv(double **tu, double **tv, double **u, double **v, double **worku, double **workv, double **fx, double **fy, double **adv_u, double **adv_v);

void temp_uv2(double **tu, double **tv, double **u, double **v, double **ou, double **ov, double **worku, double **workv, double **fx, double **fy, double **adv_u, double **adv_v);

void relax_uv(double **tu, double **tv, double **su, double **sv, int nx, int ny);

void relax_uv2(double **tu, double **tv, double **su, double **sv, int nx, int ny);

void Poisson(double **tu, double **tv, double **p, double **np);

void source_uv(double **tu, double **tv, double **p, double **divuv, int nxt, int nyt);

void Poisson2(double **tu, double **tv, double **p, double **np);

void source_uv2(double **tu, double **tv, double **p, double **divuv, int nxt, int nyt);

void div_uv(double **tu, double **tv, double **divuv, int nxt, int nyt);

void MG_Poisson(double **p, double **f);

void vcycle_uv(double **uf, double **ff, double **wf, int nxf, int nyf, int ilevel);

void relax_p(double **p, double **f, double **w, int ilevel, int nxt, int nyt);

void residual_den(double **r, double **u, double **f, double **den, int nxt, int nyt);

void grad_p(double **p, double **dpdx, double **dpdy, int nxt, int nyt);

void restrict1(double **u_fine, double **u_coarse, int nxt, int nyt);

void prolong(double **u_coarse, double **u_fine, int nxt, int nyt);

void pressure_update(double **a);

void augmenc(double **c, int nxt, int nyt);

void augmenuv(double **u, double **v);

void augmentuv(double **u, double **v);

void advection_step(double **u, double **v, double **c, double **adv_c);

void advection_uv(double **u, double **v, double **adv_u, double **adv_v);

void cahn(double **c_old, double **mu, double **adv_c, double **f, double **c_new);

void cahn2(double **cc_old, double **c_old, double **mu, double **adv_c, double **f, double **of, double **c_new);

void source(double **c_old, double **f, double **adv_c, double **src_c, double **src_mu);

void source2(double **cc_old, double **c_old, double **f, double **of, double **adv_c, double **src_c, double **src_mu);

void laplace_ch(double **a, double **lap_a, int nxt, int nyt);

void vcycle(double **uf_new, double **wf_new, double **su, double **sw, int nxf, int nyf, int ilevel);

void vcycle2(double **uf_new, double **wf_new, double **su, double **sw, int nxf, int nyf, int ilevel);

void relax(double **c_new, double **mu_new, double **su, double **sw, int ilevel, int nxt, int nyt);

void relax2(double **c_new, double **mu_new, double **su, double **sw, int ilevel, int nxt, int nyt);

void defect(double **duc, double **dwc, double **uf_new, double **wf_new,
            double **suf, double **swf, int nxf, int nyf);

void defect2(double **duc, double **dwc, double **uf_new, double **wf_new,
            double **suf, double **swf, int nxf, int nyf);

void nonL(double **ru, double **rw, double **c_new, double **mu_new, int nxt, int nyt);

void nonL2(double **ru, double **rw, double **c_new, double **mu_new, int nxt, int nyt);

void restrict2(double **uf, double **uc, double **vf, double **vc, int nxt, int nyt);

void prolong_ch(double **uc, double **uf, double **vc, double **vf, int nxt, int nyt);

double error(double **c_old, double **c_new, int nxt, int nyt);


